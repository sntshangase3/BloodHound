package com.example.sibusiso_javapracticaltest;

import android.app.Fragment;

import android.os.Bundle;


import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.TextView;


public class DetailFragment extends Fragment {




    int id;
    View rootView;
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        rootView = inflater.inflate(R.layout.activity_detail, container, false);




        Bundle bundle = this.getArguments();

        try {
            if (bundle != null) {


                     id =bundle.getInt("ID");

                LoadPokeMonData(id);


            }
        } catch (Exception ex) {
            Log.d("ReminderService In", "####1" + ex.getMessage());
        }


        return rootView;
    }

    private void LoadPokeMonData(final int pokeid) {


    }

}
