package com.example.sibusiso_javapracticaltest;

import android.app.AlertDialog;
import android.app.Fragment;
import android.app.FragmentManager;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputType;
import android.util.Base64;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Created by Sbusiso.
 */
public class HomeFragment extends Fragment implements AdapterView.OnItemSelectedListener {
    View rootView;
    FragmentManager fragmentManager;

    ArrayList<Integer> item_id = new ArrayList<Integer>();
    ArrayList<Bitmap> image = new ArrayList<Bitmap>();
    ArrayList<String> item_name = new ArrayList<String>();
    ArrayList<String> item_type = new ArrayList<String>();
    Connection con;
    String un, pass, db, ip;

    ListView lstgross;
    ImageView edtlogoImage, edtprofileImage;
    Bundle bundle;
    String contact, email, address, firstname, password, lonlat, userrole;
    MainActivity activity = MainActivity.instance;
    ImageView b3, b4;
    byte[] byteArray;
    String encodedImage;

    public HomeFragment() {

        super();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        rootView = inflater.inflate(R.layout.fragment_homee, container, false);
        lstgross = (ListView) rootView.findViewById(R.id.lstgross);
        fragmentManager = getFragmentManager();
        edtlogoImage = (ImageView) rootView.findViewById(R.id.imgLogo);
        edtprofileImage = (ImageView) rootView.findViewById(R.id.profileImage);


        b3 = (ImageView) rootView.findViewById(R.id.b3);
        b4 = (ImageView) rootView.findViewById(R.id.b4);


        // Declaring Server ip, username, database name and password
        ip = "winsqls01.cpt.wa.co.za";
        db = "SqaloITSolutionsTest";
        un = "sqaloits";
        pass = "422q5mfQzU";


        bundle = this.getArguments();


        try {

            LoadUserData();

        } catch (Exception ex) {
            Log.d("ReminderService In", ex.getMessage());
            Toast.makeText(rootView.getContext(), "Fail Load User Details,Check your network connection!!", Toast.LENGTH_LONG).show();
        }


        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    Intent callnoIntent = new Intent(Intent.ACTION_CALL);
                    callnoIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    callnoIntent.setData(Uri.parse("tel:" + contact));
                    getActivity().startActivity(callnoIntent);
                } catch (SecurityException ex) {
                    Toast.makeText(rootView.getContext(), "Chef Tel/Cell No Invalid!!", Toast.LENGTH_LONG).show();
                }

            }
        });
        b4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(rootView.getContext(), MainActivitySms.class);
                startActivity(i);

            }
        });

        return rootView;
    }

    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int position, long l) {

        //Toast.makeText(rootView.getContext(), "You've selected " + String.valueOf(position)+" "+pokeId+" "+l , Toast.LENGTH_LONG).show();
        // Log.d("POKEMON", "You've selected " + String.valueOf(position)+" "+pokeId+" "+l);
    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }

    public void LoadUserData() {

        try {
            ConnectionClass cn = new ConnectionClass();
            con = cn.connectionclass(un, pass, db, ip);
            if (con == null) {
                Toast.makeText(rootView.getContext(), "Check your network connection!!", Toast.LENGTH_LONG).show();
            } else {


                GPSTracker mGPS = new GPSTracker(rootView.getContext());
                if (mGPS.canGetLocation) {
                    mGPS.getLocation();
                    double latitude = mGPS.getLatitude();
                    double longitude = mGPS.getLongitude();
                    Geocoder geocoder;
                    List<Address> addresses;
                    geocoder = new Geocoder(rootView.getContext(), Locale.getDefault());
                    addresses = geocoder.getFromLocation(latitude, longitude, 1);

                    address = addresses.get(0).getAddressLine(0);
                    lonlat = "lat/lng: (" + String.valueOf(latitude) + "," + String.valueOf(longitude) + ")";

                } else {
                    Log.d("ReminderService In", "GPS OFF");
                    mGPS.showSettingsAlert();
                }
                boolean isfound = false;

                String query = "select * from [AppUser] where [email]='" + activity.edtuseremail.getText().toString() + "' order by [id] asc";
                PreparedStatement ps = con.prepareStatement(query);
                ResultSet rs = ps.executeQuery();
                while (rs.next()) {


//Check current location exist on the logs as we login/open the app
                    if (lonlat.equals(rs.getString("provice"))) {
                        isfound = true;
                        Log.d("ReminderService In", "GPS EXIST");
                    }

                    try {
                        if (rs.getString("image") != null) {
                            contact = rs.getString("contact");
                            byte[] decodeString = Base64.decode(rs.getString("image"), Base64.DEFAULT);
                            Bitmap decodebitmap = BitmapFactory.decodeByteArray(decodeString, 0, decodeString.length);
                            edtprofileImage.setImageBitmap(decodebitmap);

                            Bitmap b = BitmapFactory.decodeResource(rootView.getContext().getResources(), R.drawable.map_search);
                            item_id.add(Integer.valueOf(rs.getString("id")));
                            image.add(b);
                            item_name.add(rs.getString("location"));
                            item_type.add(rs.getString("provice"));

                            firstname = rs.getString("firstname");
                            email = rs.getString("email");
                            encodedImage = encodedImage = rs.getString("image");


                        } else {
                            contact = rs.getString("contact");
                            edtprofileImage.setImageDrawable(rootView.getResources().getDrawable(R.drawable.profilephoto));

                            Bitmap b = BitmapFactory.decodeResource(rootView.getContext().getResources(), R.drawable.map_search);
                            item_id.add(Integer.valueOf(rs.getString("id")));
                            image.add(b);
                            item_name.add(rs.getString("location"));
                            item_type.add(rs.getString("provice"));

                            firstname = rs.getString("firstname");
                            email = rs.getString("email");


                        }
                    } catch (Exception e) {
                        Log.d("ReminderService In", e.getMessage());
                    }

                    if(rs.isLast()){
                        if (!isfound) {
                            if (!lonlat.equals("")) {
                                String querynew = "insert into [AppUser]([firstname],[location],[email],[password],[contact],[provice],[birthyear],[gender],[userRole],[image]) " +
                                        "values ('" + firstname + "','" + address + "','" + email + "','password','0716858265','" + lonlat + "','2019','Male','2','" + encodedImage + "')";
                                PreparedStatement preparedStatement = con.prepareStatement(querynew);
                                preparedStatement.executeUpdate();
                                Log.d("ReminderService In", "GPS Added");

                                query = "select * from [AppUser] where [provice]='" + lonlat + "'";
                              ps = con.prepareStatement(query);
                          rs = ps.executeQuery();
                          rs.next();
                                Bitmap b = BitmapFactory.decodeResource(rootView.getContext().getResources(), R.drawable.map_search);
                                item_id.add(Integer.valueOf(rs.getString("id")));
                                image.add(b);
                                item_name.add(rs.getString("location"));
                                item_type.add(rs.getString("provice"));

                            }
                        }
                    }

                }



                LocationAdapter adapter = new LocationAdapter(getActivity(), item_id, image, item_name, item_type);
                lstgross.setAdapter(adapter);
                lstgross.setOnItemClickListener(new AdapterView.OnItemClickListener() {

                    @Override
                    public void onItemClick(AdapterView<?> parent, View view,
                                            final int position, long id) {

                        final int selectedid = item_id.get(position);
                        final String selectedname = item_name.get(position);
                        final String selectedlatlon = item_type.get(position);
                        Toast ToastMessage = Toast.makeText(rootView.getContext(), "You've selected " + selectedname, Toast.LENGTH_LONG);
                        View toastView = ToastMessage.getView();
                        toastView.setBackgroundResource(R.drawable.toast_bground);
                        ToastMessage.show();


                        try {
                            AlertDialog.Builder builder = new AlertDialog.Builder(rootView.getContext());
                            TextView title=new TextView(rootView.getContext());
                            title.setPadding(10,10,10,10);
                            title.setText("Select Option");
                            title.setGravity(Gravity.CENTER);
                            title.setTextColor(getResources().getColor(R.color.colorPrimary));
                            builder.setCustomTitle(title);
                            builder.setMessage(selectedname);
                            builder.setIcon(rootView.getResources().getDrawable(R.drawable.map_search));
                            builder.setPositiveButton("View Map", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                  //  Fragment fragment = new DetailFragment();
                                    Log.d("ReminderService In", selectedname);
                                    Fragment fragment = new WeatherFragment();
                                    Bundle bundle = new Bundle();
                                    bundle.putInt("ID", selectedid);
                                    bundle.putString("address", selectedname);
                                    bundle.putString("latlon", selectedlatlon);
                                    fragment.setArguments(bundle);
                                    FragmentManager fragmentManager = getFragmentManager();
                                    fragmentManager.beginTransaction().replace(R.id.mainFrame, fragment).commit();
                                }
                            });
                            builder.setNegativeButton("Edit", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {

                                    Fragment fragment = new RegisterFrag();
                                    Bundle bundle = new Bundle();
                                    bundle.putInt("ID", selectedid);
                                    fragment.setArguments(bundle);
                                    FragmentManager fragmentManager = getFragmentManager();
                                    fragmentManager.beginTransaction().replace(R.id.mainFrame, fragment).commit();
                                }
                            });
                            builder.show();



                        } catch (Exception ex) {

                        }


                    }
                });


            }


        } catch (Exception ex) {
            Log.d("ReminderService In", ex.getMessage());
        }
//===========

    }


}








